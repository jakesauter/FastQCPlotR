## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, 
                      message = FALSE, 
                      error = FALSE)

## -----------------------------------------------------------------------------
library(FastQCPlotR)
library(magrittr)
library(ggplot2)
library(dplyr)
library(knitr)

## -----------------------------------------------------------------------------
args(reading_in)

## -----------------------------------------------------------------------------
fastqc_data_file <- 
   system.file('extdata', 
            '/fastqc_files/ERR458493_fastqc_data.txt', 
            package = "FastQCPlotR")

reading_in(fastqc_data_file) %>% 
   head() %>% 
   kable()

## -----------------------------------------------------------------------------
body(reading_in)

## -----------------------------------------------------------------------------
test = "Per base sequence quality"
file = '/home/x1/Documents/Weill_Cornell/ANGSD/homework/FastQCPlotR/data/ERR458497_fastqc/fastqc_data.txt'

paste0("sed -n '/", test, "/,/END_MODULE/p' ", 
        file, " | grep -v '^>>'")

## -----------------------------------------------------------------------------
samp_map_file <- system.file("extdata", 'sample_mapping.tsv', package="FastQCPlotR")

sample_mapping <- read.csv(samp_map_file, sep = '\t') 

samples <- sample_mapping[sample_mapping$Sample == "WT" &
               sample_mapping$Lane %in% c(1,2) &
               sample_mapping$BiolRep %in% c(1,2), ]

samples %>% kable()

## -----------------------------------------------------------------------------
run_accs <- samples$RunAccession

fastqc_files <-
   system.file("extdata", 
      paste0('fastqc_files/', run_accs, '_fastqc_data.txt'),
       package="FastQCPlotR")

names(fastqc_files) <- samples$RunAccession

fastqc_files %>% 
   as.data.frame() %>% 
   t() %>% 
   kable()

## -----------------------------------------------------------------------------
fastqc_results <- vector('list', length(fastqc_files))
names(fastqc_results) <- names(fastqc_files)

for (sample_name in names(fastqc_files)) {
   fastqc_results[[sample_name]] <- 
      reading_in(file = fastqc_files,
                 sample_name = sample_name)
}

df <- fastqc_results %>% 
   bind_rows() 

df %>% 
   head() %>% 
   kable()

## -----------------------------------------------------------------------------
body(plot_per_base_seq_qual)

## -----------------------------------------------------------------------------
sample_groups <- paste0(samples$Sample, '_', samples$BiolRep)
names(sample_groups) <- samples$RunAccession

fastqc_plotr_sample_df <- df %>%
   mutate(sample_group = sample_groups[sample_name])

# usethis::use_data(fastqc_plotr_sample_df)

fastqc_plotr_sample_df %>% 
   plot_per_base_seq_qual()

## -----------------------------------------------------------------------------
FastQCPlotR::fastqc_plotr_sample_df %>% 
   plot_per_base_seq_qual()

